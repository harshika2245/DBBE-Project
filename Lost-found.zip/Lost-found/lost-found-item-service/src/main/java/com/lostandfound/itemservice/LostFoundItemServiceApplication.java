package com.lostandfound.itemservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LostFoundItemServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LostFoundItemServiceApplication.class, args);
	}

}
