package com.lostandfound.itemservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lostandfound.itemservice.entity.Item;

public interface ItemRepository extends JpaRepository<Item, Integer> {

    List<Item> findByUserId(Integer userId);

    List<Item> findByItemType(Item.ItemType itemType);

    List<Item> findByStatus(Item.ItemStatus status);

    List<Item> findByVerificationStatus(Item.VerificationStatus verificationStatus);
}