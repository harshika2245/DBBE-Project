package com.lostandfound.itemservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LostFoundItemServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
