package com.lostandfound.lost_found_backend.service;

import java.util.List;
import java.util.Optional;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.lostandfound.lost_found_backend.entity.User;
import com.lostandfound.lost_found_backend.repository.UserRepository;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
        this.passwordEncoder = new BCryptPasswordEncoder();
    }

    public User registerUser(User user) {

        if (userRepository.existsByUsername(user.getUsername())) {
            throw new RuntimeException("Username already exists");
        }

        if (userRepository.existsByEmail(user.getEmail())) {
            throw new RuntimeException("Email already exists");
        }

        user.setPassword(passwordEncoder.encode(user.getPassword()));

return userRepository.save(user);
    }
    public Optional<User> loginUser(String username, String password) {
    Optional<User> user = userRepository.findByUsername(username);

    if (user.isPresent() && passwordEncoder.matches(password, user.get().getPassword())) {
        return user;
    }

    return Optional.empty();
}

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public Optional<User> getUserById(Integer id) {
        return userRepository.findById(id);
    }

    public Optional<User> getUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public User updateUser(Integer id, User updatedUser) {

        User existingUser = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        existingUser.setFullName(updatedUser.getFullName());
        existingUser.setPhone(updatedUser.getPhone());
        existingUser.setRollNumber(updatedUser.getRollNumber());
        existingUser.setDepartment(updatedUser.getDepartment());
        existingUser.setBio(updatedUser.getBio());
        existingUser.setShowContact(updatedUser.getShowContact());
        existingUser.setEmailNotifications(updatedUser.getEmailNotifications());

        return userRepository.save(existingUser);
    }

    public void deleteUser(Integer id) {

        if (!userRepository.existsById(id)) {
            throw new RuntimeException("User not found");
        }

        userRepository.deleteById(id);
    }
}