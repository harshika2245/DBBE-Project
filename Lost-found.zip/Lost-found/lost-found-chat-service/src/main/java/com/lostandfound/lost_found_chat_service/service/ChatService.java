package com.lostandfound.lost_found_chat_service.service;

import com.lostandfound.lost_found_chat_service.entity.ChatMessage;
import com.lostandfound.lost_found_chat_service.repository.ChatRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ChatService {

    private final ChatRepository chatRepository;

    public ChatService(ChatRepository chatRepository) {
        this.chatRepository = chatRepository;
    }

    public ChatMessage sendMessage(ChatMessage message) {
        return chatRepository.save(message);
    }

    public List<ChatMessage> getAllMessages() {
        return chatRepository.findAll();
    }

    public Optional<ChatMessage> getMessageById(Integer id) {
        return chatRepository.findById(id);
    }

    public List<ChatMessage> getMessagesBySender(Integer senderId) {
        return chatRepository.findBySenderId(senderId);
    }

    public List<ChatMessage> getMessagesByReceiver(Integer receiverId) {
        return chatRepository.findByReceiverId(receiverId);
    }

    public List<ChatMessage> getMessagesByItem(Integer itemId) {
        return chatRepository.findByItemId(itemId);
    }

    public void deleteMessage(Integer id) {
        if (!chatRepository.existsById(id)) {
            throw new RuntimeException("Message not found");
        }

        chatRepository.deleteById(id);
    }
}