package com.lostandfound.itemservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.lostandfound.itemservice.entity.Item;
import com.lostandfound.itemservice.repository.ItemRepository;

@Service
public class ItemService {

    private final ItemRepository itemRepository;

    public ItemService(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }

    public Item createItem(Item item) {
        return itemRepository.save(item);
    }

    public List<Item> getAllItems() {
        return itemRepository.findAll();
    }

    public Optional<Item> getItemById(Integer id) {
        return itemRepository.findById(id);
    }

    public List<Item> getItemsByUserId(Integer userId) {
        return itemRepository.findByUserId(userId);
    }

    public List<Item> getItemsByType(Item.ItemType itemType) {
        return itemRepository.findByItemType(itemType);
    }

    public List<Item> getItemsByStatus(Item.ItemStatus status) {
        return itemRepository.findByStatus(status);
    }

    public Item updateItem(Integer id, Item updatedItem) {

        Item existingItem = itemRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Item not found"));

        existingItem.setItemName(updatedItem.getItemName());
        existingItem.setItemType(updatedItem.getItemType());
        existingItem.setCategory(updatedItem.getCategory());
        existingItem.setDescription(updatedItem.getDescription());
        existingItem.setLocation(updatedItem.getLocation());
        existingItem.setItemDate(updatedItem.getItemDate());
        existingItem.setItemTime(updatedItem.getItemTime());
        existingItem.setPrivateDetail(updatedItem.getPrivateDetail());
        existingItem.setImageUrl(updatedItem.getImageUrl());
        existingItem.setStatus(updatedItem.getStatus());
        existingItem.setVerificationStatus(updatedItem.getVerificationStatus());

        return itemRepository.save(existingItem);
    }

    public void deleteItem(Integer id) {

        if (!itemRepository.existsById(id)) {
            throw new RuntimeException("Item not found");
        }

        itemRepository.deleteById(id);
    }
}