package com.lostandfound.lost_found_match_service.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lostandfound.lost_found_match_service.entity.Match;
import com.lostandfound.lost_found_match_service.service.MatchService;

@RestController
@RequestMapping("/api/matches")
@CrossOrigin(origins = "*")
public class MatchController {

    private final MatchService matchService;

    public MatchController(MatchService matchService) {
        this.matchService = matchService;
    }

    @PostMapping
    public ResponseEntity<Match> createMatch(@RequestBody Match match) {
        Match savedMatch = matchService.createMatch(match);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedMatch);
    }

    @GetMapping
    public ResponseEntity<List<Match>> getAllMatches() {
        return ResponseEntity.ok(matchService.getAllMatches());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getMatchById(@PathVariable Integer id) {

        Optional<Match> match = matchService.getMatchById(id);

        if (match.isPresent()) {
            return ResponseEntity.ok(match.get());
        }

        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body("Match not found");
    }

    @GetMapping("/lost-item/{lostItemId}")
    public ResponseEntity<List<Match>> getMatchesByLostItem(
            @PathVariable Integer lostItemId) {

        return ResponseEntity.ok(
                matchService.getMatchesByLostItemId(lostItemId)
        );
    }

    @GetMapping("/found-item/{foundItemId}")
    public ResponseEntity<List<Match>> getMatchesByFoundItem(
            @PathVariable Integer foundItemId) {

        return ResponseEntity.ok(
                matchService.getMatchesByFoundItemId(foundItemId)
        );
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<List<Match>> getMatchesByStatus(
            @PathVariable Match.MatchStatus status) {

        return ResponseEntity.ok(
                matchService.getMatchesByStatus(status)
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateMatch(
            @PathVariable Integer id,
            @RequestBody Match match) {

        try {
            Match updatedMatch = matchService.updateMatch(id, match);
            return ResponseEntity.ok(updatedMatch);

        } catch (RuntimeException e) {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteMatch(@PathVariable Integer id) {

        try {
            matchService.deleteMatch(id);
            return ResponseEntity.ok("Match deleted successfully");

        } catch (RuntimeException e) {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
    }
    @GetMapping("/item/{itemId}")
public ResponseEntity<?> getItemFromItemService(
        @PathVariable Integer itemId) {

    try {
        return ResponseEntity.ok(
                matchService.getItemFromItemService(itemId)
        );
    } catch (Exception e) {
        return ResponseEntity
                .status(HttpStatus.BAD_GATEWAY)
                .body("Item Service communication failed");
    }
}
@PostMapping("/auto/{lostItemId}/{foundItemId}")
public ResponseEntity<?> createAutomaticMatch(
        @PathVariable Integer lostItemId,
        @PathVariable Integer foundItemId) {

    try {
        Match match = matchService.createAutomaticMatch(
                lostItemId,
                foundItemId
        );

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(match);

    } catch (Exception e) {

        return ResponseEntity
                .badRequest()
                .body(e.getMessage());
    }
}
@PostMapping("/auto-all")
public ResponseEntity<?> createAutomaticMatches() {

    try {
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(matchService.findAndCreateMatches());

    } catch (Exception e) {
        return ResponseEntity
                .badRequest()
                .body(e.getMessage());
    }
}
}