package com.lostandfound.lost_found_chat_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LostFoundChatServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
