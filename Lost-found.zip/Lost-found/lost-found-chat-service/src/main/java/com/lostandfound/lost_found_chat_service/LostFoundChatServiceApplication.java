package com.lostandfound.lost_found_chat_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LostFoundChatServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LostFoundChatServiceApplication.class, args);
	}

}
