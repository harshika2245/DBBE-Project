package com.lostandfound.lost_found_match_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LostFoundMatchServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(LostFoundMatchServiceApplication.class, args);
	}

}
