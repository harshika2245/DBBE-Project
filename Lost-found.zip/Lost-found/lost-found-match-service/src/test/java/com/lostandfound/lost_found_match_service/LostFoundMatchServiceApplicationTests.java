package com.lostandfound.lost_found_match_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LostFoundMatchServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
