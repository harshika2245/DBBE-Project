package com.lostandfound.lost_found_chat_service.controller;

import com.lostandfound.lost_found_chat_service.entity.ChatMessage;
import com.lostandfound.lost_found_chat_service.service.ChatService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/chat")
@CrossOrigin(origins = "*")
public class ChatController {

    private final ChatService chatService;

    public ChatController(ChatService chatService) {
        this.chatService = chatService;
    }

    @PostMapping
    public ResponseEntity<ChatMessage> sendMessage(
            @RequestBody ChatMessage message) {

        ChatMessage savedMessage = chatService.sendMessage(message);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(savedMessage);
    }

    @GetMapping
    public ResponseEntity<List<ChatMessage>> getAllMessages() {
        return ResponseEntity.ok(chatService.getAllMessages());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getMessageById(
            @PathVariable Integer id) {

        Optional<ChatMessage> message =
                chatService.getMessageById(id);

        if (message.isPresent()) {
            return ResponseEntity.ok(message.get());
        }

        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body("Message not found");
    }

    @GetMapping("/sender/{senderId}")
    public ResponseEntity<List<ChatMessage>> getMessagesBySender(
            @PathVariable Integer senderId) {

        return ResponseEntity.ok(
                chatService.getMessagesBySender(senderId)
        );
    }

    @GetMapping("/receiver/{receiverId}")
    public ResponseEntity<List<ChatMessage>> getMessagesByReceiver(
            @PathVariable Integer receiverId) {

        return ResponseEntity.ok(
                chatService.getMessagesByReceiver(receiverId)
        );
    }

    @GetMapping("/item/{itemId}")
    public ResponseEntity<List<ChatMessage>> getMessagesByItem(
            @PathVariable Integer itemId) {

        return ResponseEntity.ok(
                chatService.getMessagesByItem(itemId)
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteMessage(
            @PathVariable Integer id) {

        try {
            chatService.deleteMessage(id);
            return ResponseEntity.ok("Message deleted successfully");

        } catch (RuntimeException e) {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
    }
}