package com.lostandfound.lost_found_match_service.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.lostandfound.lost_found_match_service.client.ItemClient;
import com.lostandfound.lost_found_match_service.entity.Match;
import com.lostandfound.lost_found_match_service.repository.MatchRepository;

@Service
public class MatchService {

    private final MatchRepository matchRepository;
    private final ItemClient itemClient;

    public MatchService(
            MatchRepository matchRepository,
            ItemClient itemClient) {

        this.matchRepository = matchRepository;
        this.itemClient = itemClient;
    }

    // Existing manual match creation
    public Match createMatch(Match match) {
        return matchRepository.save(match);
    }

    // NEW: automatic match creation
    public Match createAutomaticMatch(Integer lostItemId, Integer foundItemId) {

        ItemClient.ItemResponse lostItem =
                itemClient.getItemById(lostItemId);

        ItemClient.ItemResponse foundItem =
                itemClient.getItemById(foundItemId);

        // Make sure the item types are correct
        if (!"LOST".equalsIgnoreCase(lostItem.getItemType())) {
            throw new RuntimeException(
                    "First item must be a LOST item"
            );
        }

        if (!"FOUND".equalsIgnoreCase(foundItem.getItemType())) {
            throw new RuntimeException(
                    "Second item must be a FOUND item"
            );
        }

        double score = calculateMatchScore(lostItem, foundItem);

        Match match = new Match();

        match.setLostItemId(lostItemId);
        match.setFoundItemId(foundItemId);
        match.setMatchScore(score);
        match.setStatus(Match.MatchStatus.PENDING);

        return matchRepository.save(match);
    }

    // Calculate match score
    private double calculateMatchScore(
            ItemClient.ItemResponse lost,
            ItemClient.ItemResponse found) {

        double score = 0.0;

        // Item name match = 30 points
        if (sameText(lost.getItemName(), found.getItemName())) {
            score += 30;
        }

        // Category match = 25 points
        if (sameText(lost.getCategory(), found.getCategory())) {
            score += 25;
        }

        // Location match = 20 points
        if (sameText(lost.getLocation(), found.getLocation())) {
            score += 20;
        }

        // Description similarity = 15 points
        if (similarText(lost.getDescription(), found.getDescription())) {
            score += 15;
        }

        // Location coordinates = 10 points
        if (lost.getLatitude() != null
                && lost.getLongitude() != null
                && found.getLatitude() != null
                && found.getLongitude() != null) {

            double distance = calculateDistance(
                    lost.getLatitude(),
                    lost.getLongitude(),
                    found.getLatitude(),
                    found.getLongitude()
            );

            // Same / very nearby location
            if (distance <= 0.5) {
                score += 10;
            }
        }

        return score;
    }

    private boolean sameText(String first, String second) {

        if (first == null || second == null) {
            return false;
        }

        return first.trim().equalsIgnoreCase(second.trim());
    }

    private boolean similarText(String first, String second) {

        if (first == null || second == null) {
            return false;
        }

        String a = first.toLowerCase();
        String b = second.toLowerCase();

        return a.contains(b) || b.contains(a);
    }

    // Distance between two latitude/longitude points in kilometers
    private double calculateDistance(
            double lat1,
            double lon1,
            double lat2,
            double lon2) {

        final double EARTH_RADIUS = 6371.0;

        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);

        double a =
                Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1))
                * Math.cos(Math.toRadians(lat2))
                * Math.sin(dLon / 2)
                * Math.sin(dLon / 2);

        double c =
                2 * Math.atan2(
                        Math.sqrt(a),
                        Math.sqrt(1 - a)
                );

        return EARTH_RADIUS * c;
    }
    public List<Match> findAndCreateMatches() {

    List<Match> createdMatches = new java.util.ArrayList<>();

    List<ItemClient.ItemResponse> lostItems = new java.util.ArrayList<>();
    List<ItemClient.ItemResponse> foundItems = new java.util.ArrayList<>();

    // Get all items from Item Service
    List<ItemClient.ItemResponse> allItems =
            itemClient.getAllItems();

    // Separate LOST and FOUND items
    for (ItemClient.ItemResponse item : allItems) {

        if ("LOST".equalsIgnoreCase(item.getItemType())) {
            lostItems.add(item);
        }

        if ("FOUND".equalsIgnoreCase(item.getItemType())) {
            foundItems.add(item);
        }
    }

    // Compare every LOST item with every FOUND item
    for (ItemClient.ItemResponse lost : lostItems) {

        for (ItemClient.ItemResponse found : foundItems) {

            double score = calculateMatchScore(lost, found);

            // Create a match only when score is reasonably high
            if (score >= 50 &&
    !matchRepository.existsByLostItemIdAndFoundItemId(
        lost.getId(), found.getId())) {

    Match match = new Match();
    match.setLostItemId(lost.getId());
    match.setFoundItemId(found.getId());
    match.setMatchScore(score);
    match.setStatus(Match.MatchStatus.PENDING);

    createdMatches.add(matchRepository.save(match));
}
        }
    }

    return createdMatches;
}

    public List<Match> getAllMatches() {
        return matchRepository.findAll();
    }

    public Optional<Match> getMatchById(Integer id) {
        return matchRepository.findById(id);
    }

    public List<Match> getMatchesByLostItemId(Integer lostItemId) {
        return matchRepository.findByLostItemId(lostItemId);
    }

    public List<Match> getMatchesByFoundItemId(Integer foundItemId) {
        return matchRepository.findByFoundItemId(foundItemId);
    }

    public List<Match> getMatchesByStatus(Match.MatchStatus status) {
        return matchRepository.findByStatus(status);
    }

    public ItemClient.ItemResponse getItemFromItemService(Integer itemId) {
        return itemClient.getItemById(itemId);
    }

    public Match updateMatch(Integer id, Match updatedMatch) {

        Match existingMatch = matchRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Match not found"));

        existingMatch.setLostItemId(updatedMatch.getLostItemId());
        existingMatch.setFoundItemId(updatedMatch.getFoundItemId());
        existingMatch.setMatchScore(updatedMatch.getMatchScore());
        existingMatch.setStatus(updatedMatch.getStatus());

        return matchRepository.save(existingMatch);
    }

    public void deleteMatch(Integer id) {

        if (!matchRepository.existsById(id)) {
            throw new RuntimeException("Match not found");
        }

        matchRepository.deleteById(id);
    }
}