package com.lostandfound.lost_found_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LostFoundBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
