/* =========================================================
   CAMPUS RECOVERY NETWORK
   Main JavaScript
   ========================================================= */


/* =========================================================
   STORAGE
   ========================================================= */

const STORAGE = {
    users: "crn_users",
    items: "crn_items",
    matches: "crn_matches",
    notifications: "crn_notifications",
    chats: "crn_chats",
    currentUser: "crn_current_user",
    settings: "crn_settings"
};


const MATCH_THRESHOLD = 0.45;


const HOTSPOTS = [
    "Main Library",
    "Cafeteria",
    "Auditorium",
    "Boys Hostel",
    "Girls Hostel",
    "Sports Complex",
    "Main Gate",
    "CS Block",
    "ECE Block",
    "CSE Block",
    "Admin Block",
    "Parking Area"
];


/* =========================================================
   BASIC STORAGE FUNCTIONS
   ========================================================= */

function getData(key, fallback = []) {
    try {
        return JSON.parse(localStorage.getItem(key)) || fallback;
    } catch (error) {
        return fallback;
    }
}


function saveData(key, data) {
    localStorage.setItem(key, JSON.stringify(data));
}


/* =========================================================
   INITIAL DATA
   ========================================================= */

function initializeApp() {

    let users = getData(STORAGE.users, []);

    /* Create default admin */
    const adminExists = users.some(
        user => user.username === "admin"
    );

    if (!adminExists) {

        users.push({
            id: "admin-001",
            name: "Campus Administrator",
            username: "admin",
            password: "admin123",
            email: "admin@campus.edu",
            role: "Admin",
            joined: new Date().toISOString()
        });

        saveData(STORAGE.users, users);
    }


    if (!localStorage.getItem(STORAGE.items)) {
        if (!localStorage.getItem(STORAGE.items)) {
        /* Inject mock data for the demo so the map and dashboard aren't empty */
        const mockItems = [
            {
                id: "item-101",
                username: "student",
                type: "Lost",
                category: "Laptop",
                name: "MacBook Pro",
                description: "Silver MacBook Pro with a blue sticker on the back.",
                location: "Main Library",
                campusArea: "Library",
                latitude: 17.4068, 
                longitude: 78.4775,
                date: new Date().toISOString().split("T")[0],
                status: "Open",
                createdAt: new Date().toISOString()
            },
            {
                id: "item-102",
                username: "admin",
                type: "Found",
                category: "Keys",
                name: "Honda Car Keys",
                description: "Found on a table near the entrance. Has a red lanyard.",
                location: "Cafeteria",
                campusArea: "Cafeteria",
                latitude: 17.4062, 
                longitude: 78.4770,
                date: new Date().toISOString().split("T")[0],
                status: "Open",
                createdAt: new Date().toISOString()
            },
            {
                id: "item-103",
                username: "admin",
                type: "Found",
                category: "ID Card",
                name: "Student ID - Alex",
                description: "ID card found in the hallway.",
                location: "CS Block",
                campusArea: "Block A",
                latitude: 17.4070, 
                longitude: 78.4765,
                date: new Date().toISOString().split("T")[0],
                status: "Recovered",
                createdAt: new Date().toISOString()
            }
        ];
        saveData(STORAGE.items, mockItems);
    }

    if (!localStorage.getItem(STORAGE.matches)) {
        saveData(STORAGE.matches, []);
    }

    if (!localStorage.getItem(STORAGE.notifications)) {
        saveData(STORAGE.notifications, []);
    }

    if (!localStorage.getItem(STORAGE.chats)) {
        saveData(STORAGE.chats, []);
    }
}


/* =========================================================
   CURRENT USER
   ========================================================= */

function getCurrentUser() {

    const username =
        localStorage.getItem(STORAGE.currentUser);

    if (!username) {
        return null;
    }

    const users = getData(STORAGE.users, []);

    return users.find(
        user => user.username === username
    ) || null;
}


function setCurrentUser(username) {
    localStorage.setItem(
        STORAGE.currentUser,
        username
    );
}


function logout() {

    localStorage.removeItem(
        STORAGE.currentUser
    );

    window.location.href = "index.html";
}


/* =========================================================
   NAVIGATION
   ========================================================= */

function renderNav(activePage = "") {

    const navRoot =
        document.getElementById("navRoot");

    if (!navRoot) return;


    const user = getCurrentUser();


    /* HOME NAVIGATION */

    if (activePage === "home") {

        navRoot.innerHTML = `

            <header class="topnav">

                <a href="index.html" class="brand">

                    <span class="brand-mark">
                        CR
                    </span>

                    <span>
                        Campus Recovery Network
                    </span>

                </a>


                <nav class="nav-links">

                    <a href="index.html"
                       class="${activePage === "home" ? "active" : ""}">
                        Home
                    </a>

                    <a href="#services">
                        Services
                    </a>

                    <a href="login.html">
                        Sign In
                    </a>

                    <a href="signup.html"
                       class="nav-cta">
                        Get Started
                    </a>

                </nav>

            </header>

        `;

        return;
    }


    /* LOGIN / SIGNUP NAVIGATION */

    if (
        activePage === "login" ||
        activePage === "signup"
    ) {

        navRoot.innerHTML = `

            <header class="topnav">

                <a href="index.html" class="brand">

                    <span class="brand-mark">
                        CR
                    </span>

                    <span>
                        Campus Recovery Network
                    </span>

                </a>


                <nav class="nav-links">

                    <a href="index.html">
                        Home
                    </a>

                    ${
                        activePage === "login"
                        ? `
                        <a href="signup.html"
                           class="nav-cta">
                            Create Account
                        </a>
                        `
                        : `
                        <a href="login.html"
                           class="nav-cta">
                            Sign In
                        </a>
                        `
                    }

                </nav>

            </header>

        `;

        return;
    }


    /* LOGGED-IN NAVIGATION */

    if (!user) {

        navRoot.innerHTML = `

            <header class="topnav">

                <a href="index.html" class="brand">

                    <span class="brand-mark">
                        CR
                    </span>

                    <span>
                        Campus Recovery Network
                    </span>

                </a>

                <nav class="nav-links">

                    <a href="index.html">
                        Home
                    </a>

                    <a href="login.html">
                        Sign In
                    </a>

                    <a href="signup.html"
                       class="nav-cta">
                        Get Started
                    </a>

                </nav>

            </header>

        `;

        return;
    }


    navRoot.innerHTML = `

        <header class="topnav">

            <a href="dashboard.html"
               class="brand">

                <span class="brand-mark">
                    CR
                </span>

                <span>
                    Campus Recovery Network
                </span>

            </a>


            <nav class="nav-links">

                <a href="dashboard.html"
                   class="${activePage === "dashboard" ? "active" : ""}">
                    Dashboard
                </a>

                <a href="report.html"
                   class="${activePage === "report" ? "active" : ""}">
                    Report
                </a>

                <a href="chats.html"
                   class="${activePage === "chats" ? "active" : ""}">
                    Messages
                </a>

                <a href="profile.html"
                   class="${activePage === "profile" ? "active" : ""}">
                    Profile
                </a>

                ${
                    user.role === "Admin"
                    ? `
                    <a href="admin.html"
                       class="${activePage === "admin" ? "active" : ""}">
                        Admin
                    </a>
                    `
                    : ""
                }

                <button
                    class="logout-btn"
                    onclick="logout()">
                    Logout
                </button>

            </nav>

        </header>

    `;
}


/* =========================================================
   TOAST
   ========================================================= */

function showToast(message, type = "success") {

    let toastBox =
        document.getElementById("toastBox");

    if (!toastBox) {

        toastBox = document.createElement("div");

        toastBox.id = "toastBox";

        document.body.appendChild(toastBox);
    }


    const toast =
        document.createElement("div");

    toast.className =
        `toast toast-${type}`;

    toast.textContent = message;

    toastBox.appendChild(toast);


    setTimeout(() => {

        toast.style.opacity = "0";

        toast.style.transform =
            "translateY(10px)";

        setTimeout(() => {
            toast.remove();
        }, 300);

    }, 3000);
}


/* =========================================================
   LOGIN
   ========================================================= */

function setupLogin() {

    const loginForm =
        document.getElementById("loginForm");

    if (!loginForm) return;


    loginForm.addEventListener(
        "submit",
        function (event) {

            event.preventDefault();


            const username =
                document.getElementById(
                    "loginUsername"
                ).value.trim();


            const password =
                document.getElementById(
                    "loginPassword"
                ).value;


            const users =
                getData(STORAGE.users, []);


            const user =
                users.find(
                    item =>
                        item.username === username &&
                        item.password === password
                );


            if (!user) {

                showToast(
                    "Invalid username or password.",
                    "error"
                );

                return;
            }


            setCurrentUser(user.username);


            showToast(
                `Welcome back, ${user.name}!`,
                "success"
            );


            setTimeout(() => {

                if (user.role === "Admin") {
                    window.location.href =
                        "admin.html";
                } else {
                    window.location.href =
                        "dashboard.html";
                }

            }, 700);

        }
    );
}


/* =========================================================
   SIGNUP
   ========================================================= */

function setupSignup() {

    const form =
        document.getElementById("signupForm");

    if (!form) return;


    form.addEventListener(
        "submit",
        function (event) {

            event.preventDefault();


            const name =
                document.getElementById(
                    "signupName"
                )?.value.trim();


            const username =
                document.getElementById(
                    "signupUsername"
                )?.value.trim();


            const email =
                document.getElementById(
                    "signupEmail"
                )?.value.trim();


            const password =
                document.getElementById(
                    "signupPassword"
                )?.value;


            const confirmPassword =
                document.getElementById(
                    "signupConfirmPassword"
                )?.value;


            if (
                !name ||
                !username ||
                !email ||
                !password
            ) {

                showToast(
                    "Please fill in all required fields.",
                    "error"
                );

                return;
            }


            if (password !== confirmPassword) {

                showToast(
                    "Passwords do not match.",
                    "error"
                );

                return;
            }


            const users =
                getData(STORAGE.users, []);


            const exists =
                users.some(
                    user =>
                        user.username.toLowerCase() ===
                        username.toLowerCase()
                );


            if (exists) {

                showToast(
                    "Username already exists.",
                    "error"
                );

                return;
            }


            users.push({

                id:
                    "user-" +
                    Date.now(),

                name,

                username,

                email,

                password,

                role: "Student",

                joined:
                    new Date().toISOString()

            });


            saveData(
                STORAGE.users,
                users
            );


            showToast(
                "Account created successfully!",
                "success"
            );


            setTimeout(() => {

                window.location.href =
                    "login.html";

            }, 900);

        }
    );
}


/* =========================================================
   AUTH PROTECTION
   ========================================================= */

function protectPage(page) {

    const publicPages = [
        "home",
        "login",
        "signup"
    ];


    if (publicPages.includes(page)) {
        return;
    }


    const user = getCurrentUser();


    if (!user) {

        window.location.href =
            "login.html";

        return;
    }


    if (
        page === "admin" &&
        user.role !== "Admin"
    ) {

        window.location.href =
            "dashboard.html";
    }
}


/* =========================================================
   DASHBOARD
   ========================================================= */

function setupDashboard() {

    const dashboard =
        document.getElementById(
            "dashboardRoot"
        );

    if (!dashboard) return;


    const user = getCurrentUser();

    if (!user) return;


    const welcomeUser =
        document.getElementById(
            "welcomeUser"
        );

    const welcomeSub =
        document.getElementById(
            "welcomeSub"
        );


    if (welcomeUser) {
        welcomeUser.textContent =
            `Welcome back, ${user.name}`;
    }


    if (welcomeSub) {
        welcomeSub.textContent =
            "Your campus network is ready to help you.";
    }


    renderDashboardStats();

    renderDashboardItems();

    renderHotspots();

    renderNotifications();

    setupSearchAndFilters();
}


/* =========================================================
   DASHBOARD STATS
   ========================================================= */

function renderDashboardStats() {

    const items =
        getData(STORAGE.items, []);


    const total =
        items.length;


    const lost =
        items.filter(
            item => item.type === "Lost"
        ).length;


    const found =
        items.filter(
            item => item.type === "Found"
        ).length;


    const matched =
        items.filter(
            item =>
                item.status === "Matched"
        ).length;


    const recovered =
        items.filter(
            item =>
                item.status === "Recovered"
        ).length;


    setText("totalCount", total);

    setText("lostCount", lost);

    setText("foundCount", found);

    setText("matchedCount", matched);

    setText("recoveredCount", recovered);
}


function setText(id, value) {

    const element =
        document.getElementById(id);

    if (element) {
        element.textContent = value;
    }
}


/* =========================================================
   HOTSPOTS
   ========================================================= */

function setupHotspotDropdown() {

    const select =
        document.getElementById(
            "hotspotList"
        );

    if (!select) return;


    select.innerHTML =
        `<option value="">
            Select specific campus area
        </option>`;


    HOTSPOTS.forEach(
        hotspot => {

            const option =
                document.createElement("option");

            option.value = hotspot;

            option.textContent = hotspot;

            select.appendChild(option);

        }
    );
}


function renderHotspots() {

    const list =
        document.getElementById(
            "hotspotList2"
        );

    if (!list) return;


    const items =
        getData(STORAGE.items, []);


    const counts = {};


    HOTSPOTS.forEach(
        location => {
            counts[location] = 0;
        }
    );


    items.forEach(item => {

        if (counts[item.location] !== undefined) {
            counts[item.location]++;
        }

    });


    const sorted =
        Object.entries(counts)
            .sort((a, b) => b[1] - a[1]);


    list.innerHTML =
        sorted.map(
            ([location, count]) => `

                <div class="hotspot-row">

                    <span>
                        ${location}
                    </span>

                    <strong>
                        ${count}
                    </strong>

                </div>

            `
        ).join("");
}


/* =========================================================
   REPORT ITEM
   ========================================================= */

function setupReport() {

    const form =
        document.getElementById(
            "itemForm"
        );

    if (!form) return;


    setupHotspotDropdown();


    const imageInput =
        document.getElementById(
            "itemImage"
        );


    if (imageInput) {

        imageInput.addEventListener(
            "change",
            function () {

                const file =
                    this.files[0];

                if (!file) return;


                if (!file.type.startsWith("image/")) {

                    showToast(
                        "Please select an image file.",
                        "error"
                    );

                    this.value = "";

                    return;
                }


                showToast(
                    "Image selected successfully.",
                    "success"
                );
            }
        );
    }


    form.addEventListener(
        "submit",
        function (event) {

            event.preventDefault();


            const user =
                getCurrentUser();


            if (!user) {
                window.location.href =
                    "login.html";
                return;
            }


            const type =
                document.getElementById(
                    "type"
                )?.value;


            const category =
                document.getElementById(
                    "category"
                )?.value;


            const itemName =
                document.getElementById(
                    "itemName"
                )?.value.trim();


            const description =
                document.getElementById(
                    "description"
                )?.value.trim();


            const location =
                document.getElementById(
                    "location"
                )?.value ||
                document.getElementById(
                    "hotspotList"
                )?.value;


            const date =
                document.getElementById(
                    "itemDate"
                )?.value;


            const time =
                document.getElementById(
                    "itemTime"
                )?.value;


            if (
                !type ||
                !category ||
                !itemName ||
                !description ||
                !location
            ) {

                showToast(
                    "Please complete the required fields.",
                    "error"
                );

                return;
            }


            const newItem = {

                id:
                    "item-" +
                    Date.now(),

                userId:
                    user.id,

                username:
                    user.username,

                type,

                category,

                name:
                    itemName,

                description,

                location,

                date,

                time,

                status:
                    "Open",

                createdAt:
                    new Date().toISOString()

            };


            const items =
                getData(STORAGE.items, []);


            items.unshift(newItem);


            saveData(
                STORAGE.items,
                items
            );


            createNotification(
                user.username,
                `Your ${type.toLowerCase()} item "${itemName}" has been reported successfully.`
            );


            form.reset();


            const successPanel =
                document.getElementById(
                    "successPanel"
                );


            const reportFormWrap =
                document.getElementById(
                    "reportFormWrap"
                );


            if (reportFormWrap) {
                reportFormWrap.style.display =
                    "none";
            }


            if (successPanel) {

                successPanel.style.display =
                    "block";

                const successMsg =
                    document.getElementById(
                        "successMsg"
                    );

                if (successMsg) {

                    successMsg.textContent =
                        `Your ${type.toLowerCase()} report for "${itemName}" has been submitted.`;

                }
            }


            findMatches(newItem);

        }
    );
}


/* =========================================================
   MATCHING SYSTEM
   ========================================================= */

function calculateSimilarity(text1, text2) {

    if (!text1 || !text2) {
        return 0;
    }


    const words1 =
        text1.toLowerCase()
            .split(/\s+/)
            .filter(Boolean);


    const words2 =
        text2.toLowerCase()
            .split(/\s+/)
            .filter(Boolean);


    if (
        words1.length === 0 ||
        words2.length === 0
    ) {
        return 0;
    }


    const common =
        words1.filter(
            word => words2.includes(word)
        );


    const total =
        new Set([
            ...words1,
            ...words2
        ]).size;


    return total === 0
        ? 0
        : common.length / total;
}


function calculateMatchScore(itemA, itemB) {

    let score = 0;


    /* Category */
    if (
        itemA.category &&
        itemA.category === itemB.category
    ) {
        score += 0.4;
    }


    /* Location */
    if (
        itemA.location &&
        itemA.location === itemB.location
    ) {
        score += 0.3;
    }


    /* Text */
    const similarity =
        calculateSimilarity(
            `${itemA.name} ${itemA.description}`,
            `${itemB.name} ${itemB.description}`
        );


    score += similarity * 0.3;


    return Math.min(score, 1);
}


function findMatches(newItem) {

    const items =
        getData(STORAGE.items, []);


    const matches =
        getData(STORAGE.matches, []);


    items.forEach(item => {

        if (item.id === newItem.id) {
            return;
        }


        if (item.type === newItem.type) {
            return;
        }


        const score =
            calculateMatchScore(
                newItem,
                item
            );


        if (score >= MATCH_THRESHOLD) {

            const exists =
                matches.some(
                    match =>
                        (
                            match.itemA === newItem.id &&
                            match.itemB === item.id
                        ) ||
                        (
                            match.itemA === item.id &&
                            match.itemB === newItem.id
                        )
                );


            if (!exists) {

                matches.push({

                    id:
                        "match-" +
                        Date.now() +
                        "-" +
                        Math.random(),

                    itemA:
                        newItem.id,

                    itemB:
                        item.id,

                    score:

                        Math.round(
                            score * 100
                        ),

                    createdAt:
                        new Date().toISOString()

                });


                item.status =
                    "Matched";


                newItem.status =
                    "Matched";


                const ownerA =
                    getUserById(
                        newItem.userId
                    );


                const ownerB =
                    getUserById(
                        item.userId
                    );


                if (ownerA) {

                    createNotification(
                        ownerA.username,
                        `Potential match found for "${newItem.name}" — ${Math.round(score * 100)}% confidence.`
                    );

                }


                if (ownerB) {

                    createNotification(
                        ownerB.username,
                        `Potential match found for "${item.name}" — ${Math.round(score * 100)}% confidence.`
                    );

                }

            }

        }

    });


    saveData(
        STORAGE.items,
        items
    );


    saveData(
        STORAGE.matches,
        matches
    );
}


/* =========================================================
   DASHBOARD ITEMS
   ========================================================= */

function renderDashboardItems(
    filter = "all",
    search = ""
) {

    const list =
        document.getElementById(
            "itemList"
        );

    if (!list) return;


    let items =
        getData(STORAGE.items, []);


    if (filter !== "all") {

        items =
            items.filter(
                item => {

                    if (
                        filter === "matched"
                    ) {
                        return item.status === "Matched";
                    }

                    if (
                        filter === "recovered"
                    ) {
                        return item.status === "Recovered";
                    }

                    return (
                        item.type.toLowerCase() ===
                        filter
                    );
                }
            );
    }


    if (search) {

        const query =
            search.toLowerCase();


        items =
            items.filter(
                item =>
                    item.name
                        .toLowerCase()
                        .includes(query) ||

                    item.description
                        .toLowerCase()
                        .includes(query) ||

                    item.location
                        .toLowerCase()
                        .includes(query)
            );
    }


    if (items.length === 0) {

        list.innerHTML = `

            <div class="empty-state">

                <div>
                    🔎
                </div>

                <h3>
                    No reports found
                </h3>

                <p>
                    Try another filter or search term.
                </p>

            </div>

        `;

        return;
    }


    list.innerHTML =
        items.map(
            item => `

                <article class="item">

                    <div class="item-main">

                        <div class="item-icon">
                            ${
                                item.type === "Lost"
                                ? "🔍"
                                : "✓"
                            }
                        </div>

                        <div>

                            <h3>
                                ${escapeHTML(item.name)}
                            </h3>

                            <p>
                                ${escapeHTML(item.description)}
                            </p>

                            <small>
                                📍 ${escapeHTML(item.location)}
                            </small>

                        </div>

                    </div>


                    <div class="item-side">

                        <span class="status-badge">
                            ${escapeHTML(item.status)}
                        </span>

                        <span class="item-type">
                            ${escapeHTML(item.type)}
                        </span>

                    </div>

                </article>

            `
        ).join("");
}


/* =========================================================
   SEARCH AND FILTERS
   ========================================================= */

function setupSearchAndFilters() {

    const search =
        document.getElementById(
            "searchInput"
        );


    if (search) {

        search.addEventListener(
            "input",
            function () {

                const active =
                    document.querySelector(
                        ".filter-pill.active"
                    );


                const filter =
                    active?.dataset.filter ||
                    "all";


                renderDashboardItems(
                    filter,
                    this.value
                );

            }
        );
    }


    const filters =
        document.querySelectorAll(
            ".filter-pill"
        );


    filters.forEach(
        button => {

            button.addEventListener(
                "click",
                function () {

                    filters.forEach(
                        item =>
                            item.classList.remove(
                                "active"
                            )
                    );


                    this.classList.add(
                        "active"
                    );


                    renderDashboardItems(
                        this.dataset.filter ||
                        "all",

                        search?.value ||
                        ""
                    );

                }
            );

        }
    );
}


/* =========================================================
   NOTIFICATIONS
   ========================================================= */

function createNotification(
    username,
    message
) {

    const notifications =
        getData(
            STORAGE.notifications,
            []
        );


    notifications.unshift({

        id:
            "notification-" +
            Date.now(),

        username,

        message,

        read: false,

        createdAt:
            new Date().toISOString()

    });


    saveData(
        STORAGE.notifications,
        notifications
    );
}


function renderNotifications() {

    const list =
        document.getElementById(
            "notifList"
        );

    if (!list) return;


    const user =
        getCurrentUser();

    if (!user) return;


    const notifications =
        getData(
            STORAGE.notifications,
            []
        ).filter(
            notification =>
                notification.username ===
                user.username
        );


    if (notifications.length === 0) {

        list.innerHTML = `

            <div class="empty-state">

                <p>
                    No new notifications.
                </p>

            </div>

        `;

        return;
    }


    list.innerHTML =
        notifications
            .slice(0, 8)
            .map(
                notification => `

                    <div class="notification-item">

                        <span class="notification-dot">
                            ●
                        </span>

                        <div>

                            <p>
                                ${escapeHTML(
                                    notification.message
                                )}
                            </p>

                            <small>
                                ${formatDate(
                                    notification.createdAt
                                )}
                            </small>

                        </div>

                    </div>

                `
            ).join("");
}


/* =========================================================
   CHAT
   ========================================================= */

function setupChats() {

    const chatList =
        document.getElementById(
            "chatList"
        );

    const chatWindow =
        document.getElementById(
            "chatWindow"
        );


    if (!chatList || !chatWindow) {
        return;
    }


    const user =
        getCurrentUser();


    if (!user) return;


    renderChatList(
        chatList,
        chatWindow
    );
}


function renderChatList(
    chatList,
    chatWindow
) {

    const users =
        getData(
            STORAGE.users,
            []
        ).filter(
            user => user.username !==
                getCurrentUser()?.username
        );


    if (users.length === 0) {

        chatList.innerHTML = `
            <div class="empty-state">
                <p>No other users yet.</p>
            </div>
        `;

        return;
    }


    chatList.innerHTML =
        users.map(
            user => `

                <button
                    class="chat-contact"
                    onclick="openChat('${escapeAttribute(user.username)}')">

                    <span class="chat-avatar">
                        ${getInitials(user.name)}
                    </span>

                    <span>
                        <strong>
                            ${escapeHTML(user.name)}
                        </strong>

                        <small>
                            ${escapeHTML(user.role)}
                        </small>
                    </span>

                </button>

            `
        ).join("");
}


function openChat(username) {

    const chatWindow =
        document.getElementById(
            "chatWindow"
        );

    if (!chatWindow) return;


    const currentUser =
        getCurrentUser();


    if (!currentUser) return;


    const users =
        getData(
            STORAGE.users,
            []
        );


    const otherUser =
        users.find(
            user =>
                user.username === username
        );


    if (!otherUser) return;


    chatWindow.innerHTML = `

        <div class="chat-header">

            <span class="chat-avatar">
                ${getInitials(otherUser.name)}
            </span>

            <div>

                <strong>
                    ${escapeHTML(otherUser.name)}
                </strong>

                <small>
                    ${escapeHTML(otherUser.role)}
                </small>

            </div>

        </div>


        <div
            class="chat-messages"
            id="chatMessages">
        </div>


        <form
            class="chat-input"
            id="messageForm">

            <input
                type="text"
                id="messageInput"
                placeholder="Type a message..."
                required
            >

            <button type="submit">
                Send
            </button>

        </form>

    `;


    renderMessages(
        currentUser.username,
        otherUser.username
    );


    document
        .getElementById("messageForm")
        ?.addEventListener(
            "submit",
            function (event) {

                event.preventDefault();


                const input =
                    document.getElementById(
                        "messageInput"
                    );


                const text =
                    input.value.trim();


                if (!text) return;


                const chats =
                    getData(
                        STORAGE.chats,
                        []
                    );


                chats.push({

                    id:
                        "message-" +
                        Date.now(),

                    from:
                        currentUser.username,

                    to:
                        otherUser.username,

                    message:
                        text,

                    createdAt:
                        new Date().toISOString()

                });


                saveData(
                    STORAGE.chats,
                    chats
                );


                input.value = "";


                renderMessages(
                    currentUser.username,
                    otherUser.username
                );


                createNotification(
                    otherUser.username,
                    `New message from ${currentUser.name}.`
                );

            }
        );
}


function renderMessages(
    usernameA,
    usernameB
) {

    const container =
        document.getElementById(
            "chatMessages"
        );

    if (!container) return;


    const chats =
        getData(
            STORAGE.chats,
            []
        ).filter(
            chat =>
                (
                    chat.from === usernameA &&
                    chat.to === usernameB
                ) ||
                (
                    chat.from === usernameB &&
                    chat.to === usernameA
                )
        );


    if (chats.length === 0) {

        container.innerHTML = `

            <div class="empty-state">

                <p>
                    Start the conversation.
                </p>

            </div>

        `;

        return;
    }


    container.innerHTML =
        chats.map(
            chat => `

                <div class="
                    message-bubble
                    ${
                        chat.from === usernameA
                        ? "message-sent"
                        : "message-received"
                    }
                ">

                    <p>
                        ${escapeHTML(chat.message)}
                    </p>

                    <small>
                        ${formatDate(chat.createdAt)}
                    </small>

                </div>

            `
        ).join("");


    container.scrollTop =
        container.scrollHeight;
}


/* =========================================================
   PROFILE
   ========================================================= */

function setupProfile() {

    const root =
        document.getElementById(
            "profileRoot"
        );

    if (!root) return;


    const user =
        getCurrentUser();

    if (!user) return;


    setText(
        "profileName",
        user.name
    );

    setText(
        "profileUsername",
        "@" + user.username
    );

    setText(
        "detailName",
        user.name
    );

    setText(
        "detailEmail",
        user.email
    );

    setText(
        "detailRole",
        user.role
    );

    setText(
        "detailJoined",
        formatDate(user.joined)
    );


    const items =
        getData(
            STORAGE.items,
            []
        );


    const userItems =
        items.filter(
            item =>
                item.username ===
                user.username
        );


    setText(
        "profileReports",
        userItems.length
    );


    setText(
        "profileConnections",
        getData(
            STORAGE.users,
            []
        ).length
    );


    const messages =
        getData(
            STORAGE.chats,
            []
        ).filter(
            message =>
                message.from ===
                    user.username ||
                message.to ===
                    user.username
        );


    setText(
        "profileMessages",
        messages.length
    );


    const recovered =
        userItems.filter(
            item =>
                item.status ===
                "Recovered"
        ).length;


    setText(
        "profileImpact",
        recovered
    );


    const avatar =
        document.getElementById(
            "profileAvatar"
        );


    if (avatar) {

        avatar.textContent =
            getInitials(user.name);

    }
}


/* =========================================================
   SETTINGS
   ========================================================= */

function setupSettings() {

    const privacyToggle =
        document.getElementById(
            "privacyToggle"
        );


    const notifToggle =
        document.getElementById(
            "notifToggle"
        );


    if (privacyToggle) {

        privacyToggle.addEventListener(
            "change",
            function () {

                saveSetting(
                    "privacy",
                    this.checked
                );

                showToast(
                    "Privacy setting updated."
                );

            }
        );

        privacyToggle.checked =
            getSetting(
                "privacy",
                true
            );
    }


    if (notifToggle) {

        notifToggle.addEventListener(
            "change",
            function () {

                saveSetting(
                    "notifications",
                    this.checked
                );

                showToast(
                    "Notification setting updated."
                );

            }
        );

        notifToggle.checked =
            getSetting(
                "notifications",
                true
            );
    }


    const passwordForm =
        document.getElementById(
            "passwordForm"
        );


    if (passwordForm) {

        passwordForm.addEventListener(
            "submit",
            function (event) {

                event.preventDefault();


                const user =
                    getCurrentUser();


                const currentPass =
                    document.getElementById(
                        "currentPass"
                    ).value;


                const newPass =
                    document.getElementById(
                        "newPass"
                    ).value;


                const confirmPass =
                    document.getElementById(
                        "confirmPass"
                    ).value;


                const error =
                    document.getElementById(
                        "passError"
                    );


                if (
                    currentPass !==
                    user.password
                ) {

                    if (error) {
                        error.textContent =
                            "Current password is incorrect.";
                    }

                    return;
                }


                if (
                    newPass !==
                    confirmPass
                ) {

                    if (error) {
                        error.textContent =
                            "New passwords do not match.";
                    }

                    return;
                }


                const users =
                    getData(
                        STORAGE.users,
                        []
                    );


                const index =
                    users.findIndex(
                        item =>
                            item.username ===
                            user.username
                    );


                users[index].password =
                    newPass;


                saveData(
                    STORAGE.users,
                    users
                );


                if (error) {
                    error.textContent = "";
                }


                passwordForm.reset();


                showToast(
                    "Password changed successfully."
                );

            }
        );
    }


    const deleteButton =
        document.getElementById(
            "deleteAccountBtn"
        );


    if (deleteButton) {

        deleteButton.addEventListener(
            "click",
            function () {

                const user =
                    getCurrentUser();


                if (!user) return;


                const confirmed =
                    confirm(
                        "Are you sure you want to delete your account?"
                    );


                if (!confirmed) return;


                let users =
                    getData(
                        STORAGE.users,
                        []
                    );


                users =
                    users.filter(
                        item =>
                            item.username !==
                            user.username
                    );


                saveData(
                    STORAGE.users,
                    users
                );


                localStorage.removeItem(
                    STORAGE.currentUser
                );


                window.location.href =
                    "index.html";

            }
        );
    }
}


/* =========================================================
   SETTINGS HELPERS
   ========================================================= */

function getSettings() {

    return getData(
        STORAGE.settings,
        {}
    );
}


function saveSetting(
    key,
    value
) {

    const settings =
        getSettings();


    settings[key] =
        value;


    saveData(
        STORAGE.settings,
        settings
    );
}


function getSetting(
    key,
    fallback
) {

    const settings =
        getSettings();


    return settings[key] ??
        fallback;
}


/* =========================================================
   ADMIN DASHBOARD
   ========================================================= */

function setupAdmin() {

    const root =
        document.getElementById(
            "adminRoot"
        );

    if (!root) return;


    const user =
        getCurrentUser();


    if (
        !user ||
        user.role !== "Admin"
    ) {

        window.location.href =
            "dashboard.html";

        return;
    }


    const users =
        getData(
            STORAGE.users,
            []
        );


    const items =
        getData(
            STORAGE.items,
            []
        );


    const matches =
        getData(
            STORAGE.matches,
            []
        );


    const notifications =
        getData(
            STORAGE.notifications,
            []
        );


    setText(
        "adminUsers",
        users.length
    );


    setText(
        "adminItems",
        items.length
    );


    setText(
        "adminMatches",
        matches.length
    );


    setText(
        "adminNotifications",
        notifications.length
    );


    renderAdminActivity();
}


/* =========================================================
   ADMIN ACTIVITY
   ========================================================= */

function renderAdminActivity() {

    const container =
        document.getElementById(
            "adminActivity"
        );

    if (!container) return;


    const items =
        getData(
            STORAGE.items,
            []
        );


    if (items.length === 0) {

        container.innerHTML = `

            <div class="empty-state">

                <p>
                    No activity yet.
                </p>

            </div>

        `;

        return;
    }


    container.innerHTML =
        items.slice(0, 10)
            .map(
                item => `

                    <div class="admin-activity-row">

                        <div>

                            <strong>
                                ${escapeHTML(item.name)}
                            </strong>

                            <small>
                                ${escapeHTML(item.type)}
                                report •
                                ${escapeHTML(item.location)}
                            </small>

                        </div>

                        <span class="status-badge">
                            ${escapeHTML(item.status)}
                        </span>

                    </div>

                `
            ).join("");
}


/* =========================================================
   UTILITY FUNCTIONS
   ========================================================= */

function getUserById(id) {

    const users =
        getData(
            STORAGE.users,
            []
        );


    return users.find(
        user =>
            user.id === id
    ) || null;
}


function getInitials(name) {

    if (!name) {
        return "U";
    }


    return name
        .split(" ")
        .map(
            word =>
                word.charAt(0)
        )
        .join("")
        .substring(0, 2)
        .toUpperCase();
}


function formatDate(dateString) {

    if (!dateString) {
        return "";
    }


    const date =
        new Date(dateString);


    if (isNaN(date.getTime())) {
        return dateString;
    }


    return date.toLocaleDateString(
        "en-IN",
        {
            day: "2-digit",
            month: "short",
            year: "numeric"
        }
    );
}


function escapeHTML(value) {

    if (value === undefined ||
        value === null) {
        return "";
    }


    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


function escapeAttribute(value) {

    return String(value)
        .replace(/'/g, "\\'");
}


/* =========================================================
   PAGE ROUTER
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        initializeApp();


        const page =
            document.body.dataset.page ||
            "";


        /* Navigation */

        renderNav(page);


        /* Authentication */

        protectPage(page);


        /* Page-specific functions */

        if (page === "login") {
            setupLogin();
        }


        if (page === "signup") {
            setupSignup();
        }


        if (page === "dashboard") {
            setupDashboard();
        }


        if (page === "report") {
            setupReport();
        }


        if (page === "chats") {
            setupChats();
        }


        if (page === "profile") {
            setupProfile();
        }


        if (page === "settings") {
            setupSettings();
        }


        if (page === "admin") {
            setupAdmin();
        }

    }
);
}
/* =========================================================
   GLOBAL THEME ENFORCER (Fixes all pages showing white)
   ========================================================= */
document.addEventListener("DOMContentLoaded", function () {
    const styleFixer = document.createElement("style");
    styleFixer.innerHTML = `
        body, html, .page, .page-shell, main, .container {
            background: linear-gradient(135deg, #090d16 0%, #171b36 50%, #221738 100%) !important;
            color: #f1f5f9 !important;
        }
        .card, .form-card, .info-card, .stat-card, .dashboard-preview, 
        .service-card, .compare-card, .step, .chat-sidebar, .chat-window, 
        .modal-content, .report-card, .filter-box, .action-card, article.item {
            background: rgba(23, 27, 54, 0.9) !important;
            border: 1px solid rgba(99, 102, 241, 0.3) !important;
            color: #f1f5f9 !important;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.5) !important;
        }
        h1, h2, h3, h4, h5, h6, strong {
            color: #ffffff !important;
        }
        p, span, small, label {
            color: #cbd5e1 !important;
        }
        input, select, textarea {
            background: rgba(15, 23, 42, 0.8) !important;
            border: 1.5px solid rgba(99, 102, 241, 0.4) !important;
            color: #ffffff !important;
        }
    `;
    document.head.appendChild(styleFixer);
});