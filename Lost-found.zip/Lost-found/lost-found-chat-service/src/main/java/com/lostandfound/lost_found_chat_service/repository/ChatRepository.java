package com.lostandfound.lost_found_chat_service.repository;

import com.lostandfound.lost_found_chat_service.entity.ChatMessage;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ChatRepository extends JpaRepository<ChatMessage, Integer> {

    List<ChatMessage> findBySenderId(Integer senderId);

    List<ChatMessage> findByReceiverId(Integer receiverId);

    List<ChatMessage> findByItemId(Integer itemId);
}