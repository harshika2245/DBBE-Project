package com.lostandfound.lost_found_match_service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lostandfound.lost_found_match_service.entity.Match;

public interface MatchRepository extends JpaRepository<Match, Integer> {

    List<Match> findByLostItemId(Integer lostItemId);

    List<Match> findByFoundItemId(Integer foundItemId);

    List<Match> findByStatus(Match.MatchStatus status);

    // Check whether this Lost + Found pair already has a match
    boolean existsByLostItemIdAndFoundItemId(
            Integer lostItemId,
            Integer foundItemId
    );
}